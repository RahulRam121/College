
def fillOrEmpty(val1, val2, max):
    if(max - val2) < val1:
        return val1 - (max-val2), max
    return 0, val2+val1

def addToList(new_state):
    for state in s_list:
        if state == new_state:
            return

    s_list.append(new_state)
    
def isFinalState(state):
    if state[0] == 4 or state[1] == 4:
        return True
    return False

def findNextState(state):
    
    max = (8, 5, 3)
    
    for i in range(3):
        
        if state[i] != 0:
            next1 = (i+1) % 3
            next2 = (i+2) % 3
            
            if(state[next1] != max[next1]):
                new_state = list(state)
                new_state[i], new_state[next1] = fillOrEmpty(state[i], state[next1], max[next1])  
                if(isFinalState(new_state)):
                    print(new_state)
                    return               
                addToList(tuple(new_state))
                
                if(new_state[i] != 0):
                    new_state[i], new_state[next2] = fillOrEmpty(new_state[i], new_state[next2], max[next2])   
                    if(isFinalState(new_state)):
                        print(new_state)
                        return
                    addToList(tuple(new_state))
                    
            if(state[next2] != max[next2]):   
                new_state = list(state)
                new_state[i], new_state[next2] = fillOrEmpty(state[i], state[next2], max[next2])
                if(isFinalState(new_state)):
                    print(new_state)
                    return
                addToList(tuple(new_state))
                if(new_state[i] != 0):
                    new_state[i], new_state[next1] = fillOrEmpty(new_state[i], new_state[next1], max[next1])
                    if(isFinalState(new_state)):
                        print(new_state)
                        return
                    addToList(tuple(new_state))

    next_state = s_list.pop(0)
    findNextState(next_state)


def main():
    init_state = (8, 0, 0)
    findNextState(init_state)

s_list = []
main()