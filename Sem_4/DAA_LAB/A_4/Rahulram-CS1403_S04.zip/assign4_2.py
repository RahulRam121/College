


def ptdistance(self, other):
        x_diff = (self[0] - other[0]) ** 2
        y_diff = (self[1] - other[1]) ** 2
        return (x_diff + y_diff) ** 0.5
    
def remove_point(lst):
    d=dict()
    for i in range(len(lst)-1):
        temp=[]
        for j in range(i+1,len(lst)):
            temp.append(ptdistance(lst[i],lst[j]))
        d[i]=temp
    
    Min=d[0][0]
    index=0
    pair=1
    for k in d:
        for e in range(len(d[k])):
            if(d[k][e]<Min):
                Min=d[k][e]
                index=k
                pair=k+e+1
    print("\nClosest Pair : ",lst[index],lst[pair])
    print("Shortest Distance : ",Min)
    lst.pop(index)    
    
num = int(input("Enter n : "))
lst=[]
for i in range(num):
    print("\nEnter Co-ordinate ", i+1)
    x = int(input("Enter x : "))
    y = int(input("Enter y : "))
    lst.append([x,y])
print("\nList : ",lst)
remove_point(lst)
print("\nNew List : ",lst)    