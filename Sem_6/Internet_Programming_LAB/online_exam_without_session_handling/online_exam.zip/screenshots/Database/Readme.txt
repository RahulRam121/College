Name of the database is online_exam

It consists of 2 tables.

students table for storing students name, login id, password, marks for 5 subjects and status of the exam.
question_bank table consits of question, options and answer.

Screenshots of question_bank table, students table before and after taking the exam are included.