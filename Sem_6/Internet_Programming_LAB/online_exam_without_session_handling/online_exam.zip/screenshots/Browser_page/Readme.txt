Login page inpt is handled by ExamServ.

When input matches db values, it moves to ExamQues where quesions is displayed.
if input doesn't match, user id or password error message is displayed.
If exam status is 'taken', test already taken message is displayed.

After submission of answers, it moves to ExamRes where result is displayed along with the marksheet.
Mark gets also updated in the db and status is set to 'taken'.