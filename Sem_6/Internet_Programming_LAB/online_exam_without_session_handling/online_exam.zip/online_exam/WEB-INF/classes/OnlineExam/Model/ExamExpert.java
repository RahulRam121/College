package OnlineExam.Model;
import java.util.*;
import java.sql.*;

public class ExamExpert
{
   public String checkStudent(String user_db, String password_db) throws Exception
   {
      try
      {
         String url = "jdbc:mysql://localhost:3306/online_exam";
         String user = "root";
         String password = "test1234";
         String id = null;


         //2. Load JDBC Driver and register the driver
         Class.forName("com.mysql.cj.jdbc.Driver").newInstance();

         //3. Open a Connection
         Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/online_exam?autoReconnect=true&useSSL=false", user, password);
         //Connection conn = DriverManager.getConnection(url,user,password);

         Statement st = con.createStatement();
         //String sql="INSERT INTO coffeedetails(color,brand) VALUE('lightbrown','narasurs')";

         String sql = "select * from students where login_id = \'" + user_db + "\' and password = \'" + password_db + "\';";
         ResultSet rs = st.executeQuery(sql);

         System.out.println("result in expert " + rs);


         while(rs.next()) {
            String status = rs.getString(10);
            if(status.equals("taken"))
            {
               id = "taken";
            }
            else
            {
               id = rs.getString(1);  
               System.out.println("Student id "+ id);
            }
         }

         st.close();
         con.close();

         return id;

      }
      catch(Exception e)
      {
         System.out.println(e);
         return null;
      }

   }

   public List<String> getQuestions() throws Exception {
      try
      {
         String url = "jdbc:mysql://localhost:3306/online_exam";
         String user = "root";
         String password = "test1234";

         Class.forName("com.mysql.cj.jdbc.Driver").newInstance();

         Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/online_exam?autoReconnect=true&useSSL=false", user, password);

         Statement st = con.createStatement();

         String sql = "select * from question_bank;";
         ResultSet rs = st.executeQuery(sql);

         System.out.println("result in expert " + rs);


         List<String> questions = new ArrayList<String>();

         while(rs.next())
         {
            questions.add(rs.getString(2) +";"+ rs.getString(3) +";"+ rs.getString(4) +";"+ rs.getString(5) +";"+ rs.getString(6) +";"+ rs.getString(7));
         }

         st.close();
         con.close();

         return questions;

      }
      catch(Exception e)
      {
         System.out.println(e);
         return null;
      }
   }

   public int[] getMarks(String id) throws Exception
   {
      try
      {
         String url = "jdbc:mysql://localhost:3306/online_exam";
         String user = "root";
         String password = "test1234";
         int[] marks = new int[5];

         Class.forName("com.mysql.cj.jdbc.Driver").newInstance();

         Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/online_exam?autoReconnect=true&useSSL=false", user, password);

         Statement st = con.createStatement();

         String sql = "select * from students where student_id = " + Integer.parseInt(id) + ";";
         ResultSet rs = st.executeQuery(sql);

         System.out.println("result in expert " + rs);


         List<String> questions = new ArrayList<String>();

         while(rs.next())
         {
            for(int i = 0; i < 5; i++) 
            {
               marks[i] = Integer.parseInt(rs.getString(i+5));
            }
         }

         st.close();
         con.close();

         return marks;
      }
      catch (Exception e)
      {
         System.out.println(e);
         return null;
      }
   }

   public String getName(String id) throws Exception
   {
      try
      {
         String url = "jdbc:mysql://localhost:3306/online_exam";
         String user = "root";
         String password = "test1234";
         String name = null;

         Class.forName("com.mysql.cj.jdbc.Driver").newInstance();

         Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/online_exam?autoReconnect=true&useSSL=false", user, password);

         Statement st = con.createStatement();

         String sql = "select * from students where student_id = " + Integer.parseInt(id) + ";";
         ResultSet rs = st.executeQuery(sql);

         System.out.println("result in expert " + rs);


         while(rs.next()) {
            name = rs.getString(2);
         }

         st.close();
         con.close();

         return name;

      }
      catch(Exception e)
      {
         System.out.println(e);
         return null;
      }

   }

   public void updateMark(String id, String subject, int marks) throws Exception {
      try
      {
         String url = "jdbc:mysql://localhost:3306/online_exam";
         String user = "root";
         String password = "test1234";

         Class.forName("com.mysql.cj.jdbc.Driver").newInstance();

         Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/online_exam?autoReconnect=true&useSSL=false",user,password);

         Statement st = con.createStatement();

         String sql = "UPDATE `students` SET `"+ subject +"` = '"+ marks +"', `status` = 'taken' WHERE (`student_id` = '"+ Integer.parseInt(id) +"');";
         int rs = st.executeUpdate(sql);

         System.out.println("update status " + rs);

         st.close();
         con.close();


      }
      catch(Exception e)
      {
         System.out.println(e);
      }
   }

   public void updateStatus(String id, String status) throws Exception {
      try
      {
         String url = "jdbc:mysql://localhost:3306/online_exam";
         String user = "root";
         String password = "test1234";

         Class.forName("com.mysql.cj.jdbc.Driver").newInstance();

         Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/online_exam?autoReconnect=true&useSSL=false",user,password);

         Statement st = con.createStatement();

         String sql = "UPDATE `students` SET `status` = '" + status + "' WHERE (`student_id` = '"+ Integer.parseInt(id) +"');";
         int rs = st.executeUpdate(sql);

         System.out.println("update status " + rs);

         st.close();
         con.close();

      }
      catch(Exception e)
      {
         System.out.println(e);
      }
   }

}
