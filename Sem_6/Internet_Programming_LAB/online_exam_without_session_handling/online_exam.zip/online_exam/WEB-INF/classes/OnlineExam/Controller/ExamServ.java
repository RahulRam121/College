package OnlineExam.Controller;
import OnlineExam.Model.*;

import javax.servlet.*;
import javax.servlet.http.*;
import java.io.*;
import java.util.*;

public class ExamServ extends HttpServlet //throws IOException,ServletException,Exception
{
   

   public void doPost(HttpServletRequest request, HttpServletResponse response) //throws IOException,ServletException,Exception
   {
      String username = request.getParameter("login_id");
      String password = request.getParameter("password");

      System.out.println("username Received from controller is " + username);

      ExamExpert exam = new ExamExpert();

      try
      {

         String id = exam.checkStudent(username, password);
         System.out.println("student_id is " + id);
         
         response.setContentType("text/html");
         PrintWriter out = response.getWriter();

         if(id != null) {
            if(id.equals("taken")) {
               out.print("Test already taken!");
               RequestDispatcher rd=request.getRequestDispatcher("/index.html");  
               rd.include(request, response);
            }
            else {
               exam.updateStatus(id, "active");
               request.setAttribute("id", id);
               RequestDispatcher rd = request.getRequestDispatcher("myexamques");
               rd.forward(request, response);
            }
         }
         else {
            out.print("Sorry UserName or Password Error!");  
            RequestDispatcher rd=request.getRequestDispatcher("/index.html");  
            rd.include(request, response);
         }

      }
      catch(Exception E)
      {
         System.out.println(E);
      }
   }
}

