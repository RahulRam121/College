package OnlineExam.Controller;
import OnlineExam.Model.*;

import javax.servlet.*;
import javax.servlet.http.*;
import java.io.*;
import java.util.*;

public class AdminServ extends HttpServlet //throws IOException,ServletException,Exception
{
   

   public void doPost(HttpServletRequest request, HttpServletResponse response) //throws IOException,ServletException,Exception
   {
      String username = request.getParameter("login_id");
      String password = request.getParameter("password");

      System.out.println("username Received from controller is " + username);

      AdminExpert admin = new AdminExpert();

      try
      {

         String id = admin.checkAdmin(username, password);
         System.out.println("admin_id is " + id);

         String name = admin.getAdminName(id);
         List<String> actives = admin.getActives();
         List<String> takens = admin.getTaken();

         List<String> tempactive = new ArrayList<String>();
         List<String> temptaken = new ArrayList<String>();

         for(String ids :actives) {
            tempactive.add(admin.getName(ids));
         }

         for(String ids :takens) {
            temptaken.add(admin.getName(ids));
         }

         String active = String.join(", ", tempactive);
         String taken = String.join(", ", temptaken);

         System.out.println(name + active + taken);
         response.setContentType("text/html");
         PrintWriter out = response.getWriter();

         if(id != null) {

            out.print("<!DOCTYPE html>\n<html>\n<head>\n<meta http-equiv='Content-Type' content='text/html; charset=UTF-8'>\n"+
                "<title>Result</title>\n</head><body>\n<h2>Result</h2><p>Admin Name : " + name +
                "<p>Students writing exams :"+ active + "</p><p>Students completed their exams : " + taken + "</p>"
            );
            out.print("</body>\n</html>");
         }
         else {
            out.print("Sorry UserName or Password Error!");  
            RequestDispatcher rd=request.getRequestDispatcher("/index.html");  
            rd.include(request, response);
         }

      }
      catch(Exception E)
      {
         System.out.println(E);
      }
   }
}

