package OnlineExam.Controller;
import OnlineExam.Model.*;

import javax.servlet.*;
import javax.servlet.http.*;
import java.io.*;
import java.util.*;

public class ExamServ extends HttpServlet //throws IOException,ServletException,Exception
{
   

   public void doPost(HttpServletRequest request, HttpServletResponse response) //throws IOException,ServletException,Exception
   {
      String username = request.getParameter("login_id");
      String password = request.getParameter("password");

      System.out.println("username Received from controller is " + username);

      ExamExpert exam = new ExamExpert();

      try
      {

         String id = exam.checkStudent(username, password);
         System.out.println("student_id is " + id);
         
         response.setContentType("text/html");
         PrintWriter out = response.getWriter();

         if(id != null) {
            if(id.equals("taken")) {
               out.print("Test already taken!");
               RequestDispatcher rd=request.getRequestDispatcher("/index.html");  
               rd.include(request, response);
            }
            else {
               // Cookie[] cookies = request.getCookies();
               // String userID = null;
               // if(cookies !=null){
               //    for(Cookie cookie : cookies){

               //       if(cookie.getName().equals("userID")) {
               //          userID = cookie.getValue();
               //          System.out.println("cookie user id"+userID);
               //       }
               //       if(userID != null && userID.equals(id)) {
               //          out.print("Another Session exists for the same Username!");  
               //          RequestDispatcher rd=request.getRequestDispatcher("/index.html");  
               //          rd.include(request, response);
               //       }
               //       //if(cookie.getName().equals("JSESSIONID")) sessionID = cookie.getValue();
               //    }
               // }

               

               exam.updateStatus(id, "active");

               // session
               HttpSession session = request.getSession();
               System.out.println(session.getAttribute("userID"));
               if(session.getAttribute("userID") == null || session.getAttribute("userID").equals(id) == false) {
                  session.setAttribute("userID", id);
                  session.setMaxInactiveInterval(30*60);
                  Cookie user = new Cookie("userID", id);
                  user.setMaxAge(30*60);
                  response.addCookie(user);

                  request.setAttribute("id", id);
                  RequestDispatcher rd = request.getRequestDispatcher("myexamques");
                  rd.forward(request, response);
               }
               else {
                  out.print("Another Session exists for the same Username!");  
                  RequestDispatcher rd=request.getRequestDispatcher("/index.html");  
                  rd.include(request, response);
               }
               
               //setting session to expiry in 30 mins
               

               // cookie
               
            }
         }
         else {
            out.print("Sorry UserName or Password Error!");  
            RequestDispatcher rd=request.getRequestDispatcher("/index.html");  
            rd.include(request, response);
         }

      }
      catch(Exception E)
      {
         System.out.println(E);
      }
   }
}


// <%
// //allow access only if session exists
// String user = null;
// if(session.getAttribute("user") == null){
//    response.sendRedirect("login.html");
// }else user = (String) session.getAttribute("user");
// String userName = null;
// String sessionID = null;
// Cookie[] cookies = request.getCookies();
// if(cookies !=null){
// for(Cookie cookie : cookies){
//    if(cookie.getName().equals("user")) userName = cookie.getValue();
//    if(cookie.getName().equals("JSESSIONID")) sessionID = cookie.getValue();
// }
// }


// String tempuser = null;
//                HttpSession tempsession=request.getSession(false);
//                if(tempsession.getAttribute("userID") == null) {
//                   response.sendRedirect("index.html");
//                }
//                else {
//                   tempuser = (String) tempsession.getAttribute("userID");
//                   if(tempuser.equals(id)) {
//                      out.print("Another Session exists for the same Username!");  
//                      RequestDispatcher rd=request.getRequestDispatcher("/index.html");  
//                      rd.include(request, response);
//                   }
//                }