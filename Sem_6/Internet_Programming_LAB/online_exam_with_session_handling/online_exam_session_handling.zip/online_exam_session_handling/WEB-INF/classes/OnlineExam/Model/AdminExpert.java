package OnlineExam.Model;
import java.util.*;
import java.sql.*;

public class AdminExpert
{
   public String checkAdmin(String user_db, String password_db) throws Exception
   {
      try
      {
         String url = "jdbc:mysql://localhost:3306/online_exam";
         String user = "root";
         String password = "test1234";
         String id = null;


         //2. Load JDBC Driver and register the driver
         Class.forName("com.mysql.cj.jdbc.Driver").newInstance();

         //3. Open a Connection
         Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/online_exam?autoReconnect=true&useSSL=false", user, password);
         //Connection conn = DriverManager.getConnection(url,user,password);

         Statement st = con.createStatement();
         //String sql="INSERT INTO coffeedetails(color,brand) VALUE('lightbrown','narasurs')";

         String sql = "select * from admins where login_id = \'" + user_db + "\' and password = \'" + password_db + "\';";
         ResultSet rs = st.executeQuery(sql);

         System.out.println("result in expert " + rs);


         while(rs.next()) {
            id = rs.getString(1);  
            System.out.println("Admin id "+ id);
         }

         st.close();
         con.close();

         return id;

      }
      catch(Exception e)
      {
         System.out.println(e);
         return null;
      }

   }

   public String getName(String id) throws Exception
   {
      try
      {
         String url = "jdbc:mysql://localhost:3306/online_exam";
         String user = "root";
         String password = "test1234";
         String name = null;

         Class.forName("com.mysql.cj.jdbc.Driver").newInstance();

         Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/online_exam?autoReconnect=true&useSSL=false", user, password);

         Statement st = con.createStatement();

         String sql = "select * from students where student_id = " + Integer.parseInt(id) + ";";
         ResultSet rs = st.executeQuery(sql);

         System.out.println("result in expert " + rs);


         while(rs.next()) {
            name = rs.getString(2);
         }

         st.close();
         con.close();

         return name;

      }
      catch(Exception e)
      {
         System.out.println(e);
         return null;
      }

   }

   public boolean checkID(String id) throws Exception 
   {
      try
      {
         String url = "jdbc:mysql://localhost:3306/online_exam";
         String user = "root";
         String password = "test1234";
         boolean isValid = false;


         //2. Load JDBC Driver and register the driver
         Class.forName("com.mysql.cj.jdbc.Driver").newInstance();

         //3. Open a Connection
         Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/online_exam?autoReconnect=true&useSSL=false", user, password);
         //Connection conn = DriverManager.getConnection(url,user,password);

         Statement st = con.createStatement();
         //String sql="INSERT INTO coffeedetails(color,brand) VALUE('lightbrown','narasurs')";

         String sql = "select * from students where student_id = " + Integer.parseInt(id) + ";";
         ResultSet rs = st.executeQuery(sql);

         System.out.println("result in expert " + rs);


         while(rs.next()) {
            isValid = true;
         }

         st.close();
         con.close();

         return isValid;

      }
      catch(Exception e)
      {
         System.out.println(e);
         return false;
      }

   }

   public int[] getMarks(String id) throws Exception
   {
      try
      {
         String url = "jdbc:mysql://localhost:3306/online_exam";
         String user = "root";
         String password = "test1234";
         int[] marks = new int[5];

         Class.forName("com.mysql.cj.jdbc.Driver").newInstance();

         Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/online_exam?autoReconnect=true&useSSL=false", user, password);

         Statement st = con.createStatement();

         String sql = "select * from students where student_id = " + Integer.parseInt(id) + ";";
         ResultSet rs = st.executeQuery(sql);

         System.out.println("result in expert " + rs);


         List<String> questions = new ArrayList<String>();

         while(rs.next())
         {
            for(int i = 0; i < 5; i++) 
            {
               marks[i] = Integer.parseInt(rs.getString(i+5));
            }
         }

         st.close();
         con.close();

         return marks;
      }
      catch (Exception e)
      {
         System.out.println(e);
         return null;
      }
   }

   public String getAdminName(String id) throws Exception
   {
      try
      {
         String url = "jdbc:mysql://localhost:3306/online_exam";
         String user = "root";
         String password = "test1234";
         String name = null;

         Class.forName("com.mysql.cj.jdbc.Driver").newInstance();

         Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/online_exam?autoReconnect=true&useSSL=false", user, password);

         Statement st = con.createStatement();

         String sql = "select * from admins where admin_id = " + Integer.parseInt(id) + ";";
         ResultSet rs = st.executeQuery(sql);

         System.out.println("result in expert " + rs);


         while(rs.next()) {
            name = rs.getString(2);
         }

         st.close();
         con.close();

         return name;

      }
      catch(Exception e)
      {
         System.out.println(e);
         return null;
      }

   }

   public List<String> getActives() throws Exception
   {
      try
      {
         String url = "jdbc:mysql://localhost:3306/online_exam";
         String user = "root";
         String password = "test1234";
         List<String> actives = new ArrayList<String>();

         Class.forName("com.mysql.cj.jdbc.Driver").newInstance();

         Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/online_exam?autoReconnect=true&useSSL=false", user, password);

         Statement st = con.createStatement();

         String sql = "select * from students;";
         ResultSet rs = st.executeQuery(sql);

         System.out.println("result in expert " + rs);

         while(rs.next()) {
            if(rs.getString(10).equals("active")) {
               actives.add(rs.getString(1));
            }
         }

         st.close();
         con.close();

         return actives;

      }
      catch(Exception e)
      {
         System.out.println(e);
         return null;
      }

   }

   public List<String> getTaken() throws Exception
   {
      try
      {
         String url = "jdbc:mysql://localhost:3306/online_exam";
         String user = "root";
         String password = "test1234";
         List<String> taken = new ArrayList<String>();

         Class.forName("com.mysql.cj.jdbc.Driver").newInstance();

         Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/online_exam?autoReconnect=true&useSSL=false", user, password);

         Statement st = con.createStatement();

         String sql = "select * from students;";
         ResultSet rs = st.executeQuery(sql);

         System.out.println("result in expert " + rs);

         while(rs.next()) {
            if(rs.getString(10).equals("taken")) {
               taken.add(rs.getString(1));
            }
         }

         st.close();
         con.close();

         return taken;

      }
      catch(Exception e)
      {
         System.out.println(e);
         return null;
      }

   }




}
