package OnlineExam.Controller;
import OnlineExam.Model.*;

import javax.servlet.*;
import javax.servlet.http.*;
import java.io.*;
import java.util.*;

  
public class ExamRes extends HttpServlet {  

    int total, mark = 0;
    String id, name;
    int[] marks;
    String[] subjects = {"IP", "CD", "ML", "OOAD", "FDS"};
  
    public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
    {  
  
        response.setContentType("text/html");  
        PrintWriter out = response.getWriter();  
        
        try 
        {
            id = request.getParameter("id");
            ExamExpert exam = new ExamExpert();
              
            List<String> questions = exam.getQuestions();
            total = questions.size();

            for(int i = 0; i < total; i++) 
            {
                String answer = request.getParameter("options"+i);
                String[] question = questions.get(i).toString().split(";");
                if(answer.equals(question[5])) 
                {
                    mark += 2;
                }
            }

            exam.updateStatus(id, "taken");
            exam.updateMark(id, "ip", mark);
            name = exam.getName(id);
            marks = exam.getMarks(id);

            HttpSession session = request.getSession();
            System.out.println(session.getAttribute("userID"));
            if(session.getAttribute("userID") != null || session.getAttribute("userID").equals(id) == true) {
              session.invalidate();
            }

        	out.print("<!DOCTYPE html>\n<html>\n<head>\n<meta http-equiv='Content-Type' content='text/html; charset=UTF-8'>\n"+
                "<title>Result</title>\n</head><body>\n<h2>Result</h2><p>Name : " + name +
                "<p>Scored "+ (mark) +" out of "+(total*2)+"</p><table><tr><th>Subject</th><th>Marks</th>"
            );

            for(int i = 0; i < 5; i++)
            {
                out.print("<tr><td>" + subjects[i] + "</td><td>" + marks[i] + "</td></tr>");
            }

            out.print("</table></body>\n</html>");
        }
        catch(Exception E)
    	{
            System.out.println(E);
    	}  
    }  
  
}  
