package OnlineExam.Controller;
import OnlineExam.Model.*;

import javax.servlet.*;
import javax.servlet.http.*;
import java.io.*;
import java.util.*;

public class ExamQues extends HttpServlet {  

  
    public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
    {   

	    ExamExpert exam = new ExamExpert();

	    try
		{
			String id = null;
			int count = 0;

			id = request.getAttribute("id").toString();
			System.out.println("id attribute" +id);
			// HttpSession session=request.getSession(true);
			// if(session.getAttribute("userID") == null) {
			//    response.sendRedirect("index.html");
			// }
			// else {
			// 	user = (String) session.getAttribute("userID");
			// }
			String userID = null;
			String sessionID = null;
			Cookie[] cookies = request.getCookies();
			if(cookies !=null){
				for(Cookie cookie : cookies){
					if(cookie.getName().equals("userID")) userID = cookie.getValue();

					if(cookie.getName().equals("JSESSIONID")) sessionID = cookie.getValue();
					// if(id != null && userID != null && userID.equals(id)) {
					// 	break;
					// }
				}
			}

	        List<String> questions = exam.getQuestions();

	        

			response.setContentType("text/html");
			PrintWriter out = response.getWriter();

			out.print("<!DOCTYPE html>\n<html>\n<head>\n<meta http-equiv='Content-Type' content='text/html; charset=UTF-8'>\n<title>Questions</title>\n</head>"+
			"<body>\n<h4>Name: "+ exam.getName(id) + sessionID +"</h4><form method=\"POST\" action=\"myexamres\">\n");

			for(int i = 0; i < questions.size(); i++) {
				String[] question = questions.get(i).toString().split(";");
				out.print("<h4>Question " + (i+1) + "</h4>\n<p>" + question[0] + "</p>"+
					"<input type=\"radio\" name=\"options"+ i +"\" value=\"" + question[1] + "\" required>"  + question[1] + "<br>"+
					"<input type=\"radio\" name=\"options"+ i +"\" value=\"" + question[2] + "\">"  + question[2] + "<br>"+
					"<input type=\"radio\" name=\"options"+ i +"\" value=\"" + question[3] + "\">"  + question[3] + "<br>"+
					"<input type=\"radio\" name=\"options"+ i +"\" value=\"" + question[4] + "\">"  + question[4] + "<br><br>"
				);
			}
			out.print("<input type=\"hidden\" name=\"id\" value=\"" + id + "\">");
			out.print("<input type=\"submit\" value=\"Submit\"></form>\n</body>\n</html>");

		}
		catch(Exception E)
		{
			System.out.println(E);
		}
    }  
  
}  


/*
public class ExamQues extends HttpServlet {  

   public static int correct = 0, index = 0;
   public static String id;
  
    public void doPost(HttpServletRequest request, HttpServletResponse response)  
        throws ServletException, IOException {   
          
    //String n=request.getAttribute("name").toString();  

    ExamExpert exam = new ExamExpert();

    try
	{
        List<String> questions = exam.getQuestions();

        if(request.getAttribute("id")!= null){
        	id = request.getAttribute("id").toString();
        }


		if(index != 0){
		String[] quest = questions.get(index-1).toString().split(";");
		System.out.println("Option selected = " + request.getParameter("options") + "\nAnswer = " + quest[5]);
			if(request.getParameter("options").equals(quest[5])){
				System.out.println("Correct answer. 2 marks awarded");
				correct += 1;
			}
		}
		if(index == questions.size()){
			System.out.println("All questions answered!. Redirecting to ExamRes..");
			request.setAttribute("correct", correct);
			request.setAttribute("total", questions.size());
			request.setAttribute("id", id);
			RequestDispatcher rd = request.getRequestDispatcher("myexamres");  
			rd.forward(request, response); 
			return;
		}

		String[] question = questions.get(index++).toString().split(";");
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();

		out.print("<!DOCTYPE html>\n<html>\n<head>\n<meta http-equiv='Content-Type' content='text/html; charset=UTF-8'>\n<title>Questions</title>\n</head>"+
		"<body>\n<h2>Question " + (index) + "</h2><h4>Name: "+ exam.getName(id) +"</h4><form method=\"POST\" action=\"myexamques\">\n<p>" + question[0] + "</p>"+
		"<input type=\"radio\" name=\"options\" value=\"" + question[1] + "\">"  + question[1] + "<br>"+
		"<input type=\"radio\" name=\"options\" value=\"" + question[2] + "\">"  + question[2] + "<br>"+
		"<input type=\"radio\" name=\"options\" value=\"" + question[3] + "\">"  + question[3] + "<br>"+
		"<input type=\"radio\" name=\"options\" value=\"" + question[4] + "\">"  + question[4] + "<br><br>"+
		"<input type=\"submit\" value=\"Submit\">"+
		"</form>\n</body>\n</html>");

      }
      catch(Exception E)
      {
         System.out.println(E);
      }
    }  
  
}  
*/