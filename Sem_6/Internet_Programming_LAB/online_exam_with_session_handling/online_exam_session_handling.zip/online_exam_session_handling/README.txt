javac -classpath "D:\Program Files (x86)\apache-tomcat-9.0.43\webapps\online_exam\WEB-INF\lib\servlet-api-5.5.23.jar;D:\Program Files (x86)\apache-tomcat-9.0.43\webapps\online_exam\WEB-INF\lib\mysql-connector-java-8.0.23.jar;" OnlineExam\Model\ExamExpert.java

javac -classpath "D:\Program Files (x86)\apache-tomcat-9.0.43\webapps\online_exam\WEB-INF\lib\servlet-api-5.5.23.jar;" OnlineExam\Controller\ExamServ.java

javac -classpath "D:\Program Files (x86)\apache-tomcat-9.0.43\webapps\online_exam\WEB-INF\lib\servlet-api-5.5.23.jar;" OnlineExam\Controller\ExamQues.java

javac -classpath "D:\Program Files (x86)\apache-tomcat-9.0.43\webapps\online_exam\WEB-INF\lib\servlet-api-5.5.23.jar;" OnlineExam\Controller\ExamRes.java

javac -classpath "D:\Program Files (x86)\apache-tomcat-9.0.43\webapps\online_exam\WEB-INF\lib\servlet-api-5.5.23.jar;D:\Program Files (x86)\apache-tomcat-9.0.43\webapps\online_exam\WEB-INF\lib\mysql-connector-java-8.0.23.jar;" OnlineExam\Model\AdminExpert.java

javac -classpath "D:\Program Files (x86)\apache-tomcat-9.0.43\webapps\online_exam\WEB-INF\lib\servlet-api-5.5.23.jar;" OnlineExam\Controller\AdminServ.java